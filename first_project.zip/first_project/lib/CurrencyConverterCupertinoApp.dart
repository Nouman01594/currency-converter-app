import 'package:flutter/cupertino.dart';
class CurrencyConverterCupertinoApp extends StatefulWidget{
  const CurrencyConverterCupertinoApp({super.key});
  @override
  State<CurrencyConverterCupertinoApp> createState() =>_CurrencyConverterCupertinoAppState() ;}

class _CurrencyConverterCupertinoAppState extends State<CurrencyConverterCupertinoApp>{
  double result=0;
  final TextEditingController textEditingController =TextEditingController();
  void converter(){
    setState(() {
      result=double.parse(textEditingController.text)*271;
    });
  }

  @override
  Widget build(BuildContext context) {
    return  CupertinoPageScaffold(
        navigationBar:const  CupertinoNavigationBar(
          backgroundColor:CupertinoColors.activeGreen,
          middle: Text('Currency Converter'),
        ),
        child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('PKR ${result != 0 ? result.toStringAsFixed(3) : result.toStringAsFixed(0)}',
                  style: const TextStyle(
                    color: CupertinoColors.activeGreen,
                    fontSize: 45,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Padding(padding: const EdgeInsets.all(8.0),
                  child:CupertinoTextField(
                    controller: textEditingController,
                    placeholder: 'Enter amount in usd',
                    decoration: BoxDecoration(
                      color: CupertinoColors.white,
                      border: Border.all(),
                      borderRadius:BorderRadius.circular(30),
                    ),
                    prefix: const Icon(CupertinoIcons.money_dollar,color: CupertinoColors.activeGreen,),
                    suffix: const Icon(CupertinoIcons.money_dollar,color: CupertinoColors.activeGreen,),
                    keyboardType:const TextInputType.numberWithOptions(
                      decimal: true,
                    ),
                  ),
                ),
                Padding(padding: const EdgeInsets.all(8.0),
                  child:CupertinoButton(onPressed: converter,
                    color: CupertinoColors.activeGreen,
                    child:const Text ('Convert'),
                  ),
                ),
              ],
            )
        )
    );

  }
}

