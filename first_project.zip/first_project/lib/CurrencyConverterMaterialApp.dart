import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class CurrencyConverterMaterialApp extends StatefulWidget {
  const CurrencyConverterMaterialApp({super.key});
  @override
  State<CurrencyConverterMaterialApp> createState()=> CurrencyConverterMaterialAppState();}
class CurrencyConverterMaterialAppState extends  State<CurrencyConverterMaterialApp>{
  double result=0;
  final TextEditingController textEditingController=TextEditingController();
  void converter(){
    setState(() {
      result=double.parse(textEditingController.text)*274;
    });
  }

  @override
  Widget build(BuildContext context) {

    final border=OutlineInputBorder(
      borderSide:const  BorderSide(
        style: BorderStyle.solid,
      ),
      borderRadius: BorderRadius.circular(40),
    );
    return Scaffold(
      backgroundColor: Colors.white,
      appBar:AppBar(
        backgroundColor: Colors.amberAccent,
        title:const  Text('Currency Converter App',
        style: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
        ),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('PKR ${result !=0 ? result.toStringAsFixed(3): result.toStringAsFixed(0)}'),
            Padding(padding:const EdgeInsets.all(8.0),
            child:TextField(
              controller: textEditingController,
              decoration: InputDecoration(
                hintText: 'Please enter amount in USD',
                hintStyle: const TextStyle(
                  color:Colors.black,
                ),
                prefixIcon:const  Icon(Icons.monetization_on),
                prefixIconColor: Colors.amberAccent,
                suffixIcon:const  Icon(Icons.monetization_on),
                suffixIconColor: Colors.amberAccent,
                filled: true,
                fillColor: Colors.white,
                focusedBorder:border,
                enabledBorder:border
              ),
              keyboardType:const TextInputType.numberWithOptions(
                decimal: true,
              ) ,
            ),
            ),
            Padding(padding:const EdgeInsets.all(8.0) ,
            child:TextButton(onPressed:converter,
              style: TextButton.styleFrom(
                backgroundColor: Colors.amberAccent,
                minimumSize:const Size(double.infinity, 50),
              ),
              child:const Text('Convert',style: TextStyle(color: Colors.black),),
            )
            ),
          ],
        ),
      ),
    );
  }
}
